package com.hnq40.myapplication.tuan3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView
import com.hnq40.myapplication.R

class Demo35MainActivity : AppCompatActivity() {
    var ls: ArrayList<ThongTin> = ArrayList();
    var adapter: Demo35Adapter? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_t31_main)
        var lv = findViewById<ListView>(R.id.demo31Listview1)
        ls.add(ThongTin("Nguyen Van A","18",R.drawable.dell))
        ls.add(ThongTin("Nguyen Van B","18",R.drawable.chrome))
        ls.add(ThongTin("Nguyen Van D","18",R.drawable.android))
        ls.add(ThongTin("Nguyen Van E","18",R.drawable.apple))
        ls.add(ThongTin("Nguyen Van C","18",R.drawable.hp))
        adapter= Demo35Adapter(this,ls)
        lv.adapter=adapter

    }
}