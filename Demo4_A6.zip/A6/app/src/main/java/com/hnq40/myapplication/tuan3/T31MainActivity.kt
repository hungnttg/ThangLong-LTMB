package com.hnq40.myapplication.tuan3

import androidx.appcompat.app.AppCompatActivity
import com.hnq40.myapplication.tuan3.Demo3Contact
import com.hnq40.myapplication.tuan3.T31Adapter
import android.os.Bundle
import android.widget.ListView
import com.hnq40.myapplication.R
import java.util.ArrayList

class T31MainActivity : AppCompatActivity() {
    var listView: ListView? = null
    var ls = ArrayList<Demo3Contact>()
    var adapter: T31Adapter? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_t31_main)
        listView = findViewById(R.id.demo31Listview1)
        ls.add(Demo3Contact("Nguyen Van A", "18", R.drawable.android))
        ls.add(Demo3Contact("Tran Van B", "20", R.drawable.apple))
        ls.add(Demo3Contact("Vu Van C", "16", R.drawable.blogger))
        ls.add(Demo3Contact("Hoang Thi D", "22", R.drawable.dell))
        adapter = T31Adapter(this, ls)
        listView!!.adapter=adapter
    }
}