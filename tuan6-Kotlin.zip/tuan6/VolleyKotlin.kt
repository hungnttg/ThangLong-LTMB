package com.hnq40.myapplication.tuan6

import android.content.Context
import android.widget.TextView
import com.android.volley.Response
import com.android.volley.toolbox.JsonArrayRequest
import com.android.volley.toolbox.Volley

class VolleyKotlin {
    var strJSON=""
    fun getData(context:Context?, textView: TextView)
    {
        //1. Tao request
        val queue=Volley.newRequestQueue(context)
        //2.url
        val url="https://batdongsanabc.000webhostapp.com/thanglong/array_json_new.json";
        //3. request
        val request=JsonArrayRequest(url,{response ->
            for(i in 0..response.length())
            {
                try {
                    val person=response.getJSONObject(i)
                    val id=person.getString("id")
                    val name=person.getString("name")
                    val email=person.getString("email")

                    strJSON += "Id: $id\n"
                    strJSON += "Name: $name\n"
                    strJSON += "Email: $email\n"
                }
                catch (e: java.lang.Exception)
                {
                    e.printStackTrace()
                }
            }
            textView.text=strJSON
        },{ error -> textView.text=error.message })
        //4. thuc thi request
        queue.add(request)
    }
}