package com.hnq40.myapplication.tuan3;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.hnq40.myapplication.R;
public class T33MainActivity extends AppCompatActivity {
    Spinner spinner;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_t33_main);
        spinner=findViewById(R.id.demo33Spinner);
        //1. Tao nguon du lieu
        String[] items={"item1","item2","item3","item4","item5"};
        //2. Tao adapter
        ArrayAdapter<String> adapter
                =new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,items);
        //3. gan adapter vao spinner
        spinner.setAdapter(adapter);

    }
}