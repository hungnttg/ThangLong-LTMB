package com.hnq40.myapplication.tuan3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.GridView;

import com.hnq40.myapplication.R;

import java.util.ArrayList;

public class T32MainActivity extends AppCompatActivity {
    GridView gridView;
    ArrayList<Demo3Contact> ls=new ArrayList<>();
    T32Adapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_t32_main);
        gridView=findViewById(R.id.demo32Gridview);
        ls.add(new Demo3Contact("","",R.drawable.dell));
        ls.add(new Demo3Contact("","",R.drawable.blogger));
        ls.add(new Demo3Contact("","",R.drawable.chrome));
        ls.add(new Demo3Contact("","",R.drawable.microsoft));
        ls.add(new Demo3Contact("","",R.drawable.android));
        ls.add(new Demo3Contact("","",R.drawable.firefox));
        ls.add(new Demo3Contact("","",R.drawable.apple));
        ls.add(new Demo3Contact("","",R.drawable.hp));
        ls.add(new Demo3Contact("","",R.drawable.chrome));
        adapter=new T32Adapter(this,ls);
        gridView.setAdapter(adapter);
    }
}