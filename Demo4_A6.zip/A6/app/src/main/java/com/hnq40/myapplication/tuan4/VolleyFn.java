package com.hnq40.myapplication.tuan4;

import android.content.Context;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class VolleyFn {
    String strJSON="";
    public void getJSON_Array_Of_Objects(Context context, TextView textView)
    {
        //1. Tao request
        RequestQueue queue= Volley.newRequestQueue(context);
        //2. Url
        String url="https://batdongsanabc.000webhostapp.com/thanglong/array_json_new.json";
        //3. Goi request (Mang cua cac doi tuong -> goi Mang truoc, goi Doi Tuong sau)
        //JsonArrayRequest(url, thanhCong,thatbai)
        JsonArrayRequest request=new JsonArrayRequest(url,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        //chuyen mang -> cac doi tuong
                        for (int i=0;i<response.length();i++)
                        {
                            //la doi tuong
                            try {
                                JSONObject person=response.getJSONObject(i);
                                String id=person.getString("id");
                                String name=person.getString("name");
                                String email=person.getString("email");

                                //de cho don gian -> chuyen thanh chuoi de hien thi len textview
                                strJSON += "Id: "+id+"\n";
                                strJSON += "Name: "+name+"\n";
                                strJSON += "Email: "+email+"\n";
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                        }
                        textView.setText(strJSON);
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                textView.setText(error.getMessage());
            }
        });
        //4. Thuc thi request
        queue.add(request);
    }
}
