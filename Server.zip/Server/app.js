let express = require('express'),
path = require('path'),
mysql = require('mysql'),
myConnection = require('express-myconnection'),
morgan = require('morgan');
//import router
let customerRouters = require('./routers/customer');
//tao doi tuong
const app=express();
//thiet lap
app.set('port',process.env.PORT || 3000);//cong
app.set('views',path.join(__dirname,'views'));//cap nhat duong dan
app.set('view engine','ejs');//kieu view


//ket noi
app.use(myConnection(mysql,{
     host:'sql.freedb.tech',
     user:'freedb_hungnq',
     password:'@9hc%!U9jW7Hs!k',
     port:3306,
     database:'freedb_hungnq'
}));
//
app.use(express.urlencoded({extended:false}));//ho tro json
app.use('/',customerRouters);//su dung router

//lang nghe
app.listen(app.get('port'),()=>{
     console.log("server dang chay");
});


