package com.hnq40.myapplication.tuan3;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.hnq40.myapplication.R;
public class Demo33MainActivity extends AppCompatActivity {
    Spinner spinner;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo33_main);
        spinner=findViewById(R.id.demo33Spinner);
        String[] ls= {"Item1","item2","item3","4","so5","so6"};
        ArrayAdapter<String> adapter
                =new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,ls);
        spinner.setAdapter(adapter);

    }
}