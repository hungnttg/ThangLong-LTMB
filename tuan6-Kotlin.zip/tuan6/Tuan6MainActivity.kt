package com.hnq40.myapplication.tuan6

import android.annotation.SuppressLint
import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import com.hnq40.myapplication.R
class Tuan6MainActivity : AppCompatActivity() {
    var btnGet: Button? = null
    var tvKQ: TextView? = null
    var context: Context = this
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tuan6_main)
        btnGet=findViewById(R.id.demo61Btn1)
        tvKQ=findViewById(R.id.demo61TvKQ)
        val  fn=VolleyKotlin()
        btnGet!!.setOnClickListener {
            fn.getData(context,tvKQ!!)
        }
    }
}