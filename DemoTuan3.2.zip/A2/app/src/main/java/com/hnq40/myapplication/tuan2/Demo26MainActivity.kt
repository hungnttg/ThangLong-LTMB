package com.hnq40.myapplication.tuan2

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import com.hnq40.myapplication.R

class Demo26MainActivity : AppCompatActivity() {
    var listview: ListView? = null //khai bao
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_demo26_main)
        //anh xa
        listview=findViewById(R.id.demo26Listview)//anh xa
        //B1- dinh nghia datasource
        var arr : ArrayList<String> = arrayListOf("1","2","3","4")
        //b2- dinh nghia adapter
        var adap : ArrayAdapter<String> =
                ArrayAdapter(this,android.R.layout.simple_list_item_1,arr)
        //b3- dua du lieu len listview
        listview?.adapter=adap

    }
}