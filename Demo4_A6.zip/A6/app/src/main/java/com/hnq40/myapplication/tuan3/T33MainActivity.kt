package com.hnq40.myapplication.tuan3

import androidx.appcompat.app.AppCompatActivity
import android.widget.Spinner
import android.annotation.SuppressLint
import android.os.Bundle
import com.hnq40.myapplication.R
import android.widget.ArrayAdapter

class T33MainActivity : AppCompatActivity() {
    var spinner: Spinner? = null
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_t33_main)
        spinner = findViewById(R.id.demo33Spinner)
        //1. Tao nguon du lieu
        val items = arrayOf("item1", "item2", "item3", "item4", "item5")
        //2. Tao adapter
        val adapter = ArrayAdapter(this,
                android.R.layout.simple_spinner_dropdown_item, items)
        //3. gan adapter vao spinner
        spinner!!.adapter=adapter
    }
}