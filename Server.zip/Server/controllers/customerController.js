let controller={};
//read
controller.list=(req,res)=>{
     req.getConnection((err,conn)=>{
          if(err) throw err;
          conn.query('select * from customer',(err,customers)=>{
               if(err) throw err;
               res.render('customers',{data: customers});//ket xuat
          });
     });
}
//add
controller.save=(req,res)=>{
     const data=req.body; //lay du lieu can luu
     req.getConnection((err,conn)=>{
          conn.query('insert into customer set ?',data,(err,customer)=>{
               console.log(customer);
               res.redirect('/');
          });
     });
}
//edit
controller.edit =(req,res)=>{
     const {id}=req.params;//lay ve id
     req.getConnection((err,conn)=>{
          conn.query('select * from customer where id = ?',[id],(err,rows)=>{
               res.render('customers_edit',{data:rows[0]});
          });
     });
}
//update
controller.update=(req,res)=>{
     const {id}=req.params;
     const newCustomer=req.body;
     req.getConnection((err,conn)=>{
          conn.query('update customer set ? where id= ?',
          [newCustomer,id],(err,rows)=>{
               res.redirect('/');
          });
     });
}
//delete
controller.delete=(req,res)=>{
     const {id}=req.params;
     req.getConnection((err,conn)=>{
          conn.query('delete from customer where id = ?',[id],
          (err,rows)=>{
               res.redirect('/');
          });
     });
}
//export
module.exports=controller;