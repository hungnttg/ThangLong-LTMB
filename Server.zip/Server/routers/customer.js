//dinh nghia cac thao tac co the co
let router =require('express').Router();//thu vien dieu huong
let customerController = require('../controllers/customerController');//tham chieu controller
//dinh nghia ac request
router.get('/',customerController.list);//neu goi ve trang chu, liet ke danh sach (hien thi)
router.post('/add',customerController.save);//them khach hang
router.get('/update/:id',customerController.edit);//sua
router.post('/update/:id',customerController.update);//sua
router.get('/delete/:id',customerController.delete);//xoa
module.exports = router;