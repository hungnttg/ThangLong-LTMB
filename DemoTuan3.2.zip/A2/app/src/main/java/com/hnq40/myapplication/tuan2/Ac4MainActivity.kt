package com.hnq40.myapplication.tuan2

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import com.hnq40.myapplication.R
class Ac4MainActivity : AppCompatActivity() {
    var  lv : ListView? = null
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ac4_main)
        //anh xa
        //var listview : ListView = findViewById(R.id.demo2Ac4Listview)
        lv=findViewById(R.id.demo2Ac4Listview)
        //nguon du lieu
        var arr= ArrayList<String>()
        arr.add("thanh phan 1")
        arr.add("2")
        arr.add("phan 3")
        arr.add("so 4")
        //tao adapter
        var ad: ArrayAdapter<String> = ArrayAdapter(this,
        android.R.layout.simple_list_item_1,arr)
        //gan adapter vao listview
        lv?.adapter=ad


    }
}