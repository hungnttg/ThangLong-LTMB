package com.hnq40.myapplication.tuan2

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import com.hnq40.myapplication.R

class T2ac5MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_t2ac5_main)
        var lv = findViewById<ListView>(R.id.demo2lv)//anh xa
        var arr = ArrayList<String>()//tao mang dong
        arr.add("thanh phan 1")//them du lieu vao mang dong
        arr.add("so 2")
        arr.add("ba")
        arr.add("4")
        //tao adapter
        var adap = ArrayAdapter(this,android.R.layout.simple_list_item_1,arr)
        //gan adapter vao listview
        lv.adapter=adap

    }
}