package com.hnq40.myapplication.tuan3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView
import com.hnq40.myapplication.R

class T34MainActivity : AppCompatActivity() {
    var adapter: T34Adapter? = null
    var ls: ArrayList<Contact> = ArrayList()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_t31_main)
        var listview=findViewById<ListView>(R.id.demo31Listview1)
        ls.add(Contact("Nguyen Van A","18",R.drawable.android))
        ls.add(Contact("Nguyen Van B","18",R.drawable.apple))
        ls.add(Contact("Nguyen Van D","18",R.drawable.chrome))
        ls.add(Contact("Nguyen Van C","18",R.drawable.dell))
        adapter=T34Adapter(this,ls)
        listview.adapter=adapter

    }
}