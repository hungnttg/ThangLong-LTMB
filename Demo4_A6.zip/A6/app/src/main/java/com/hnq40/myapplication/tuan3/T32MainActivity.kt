package com.hnq40.myapplication.tuan3

import androidx.appcompat.app.AppCompatActivity
import android.widget.GridView
import com.hnq40.myapplication.tuan3.Demo3Contact
import com.hnq40.myapplication.tuan3.T32Adapter
import android.os.Bundle
import com.hnq40.myapplication.R
import java.util.ArrayList

class T32MainActivity : AppCompatActivity() {
    var gridView: GridView? = null
    var ls = ArrayList<Demo3Contact>()
    var adapter: T32Adapter? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_t32_main)
        gridView = findViewById(R.id.demo32Gridview)
        ls.add(Demo3Contact("", "", R.drawable.dell))
        ls.add(Demo3Contact("", "", R.drawable.blogger))
        ls.add(Demo3Contact("", "", R.drawable.chrome))
        ls.add(Demo3Contact("", "", R.drawable.microsoft))
        ls.add(Demo3Contact("", "", R.drawable.android))
        ls.add(Demo3Contact("", "", R.drawable.firefox))
        ls.add(Demo3Contact("", "", R.drawable.apple))
        ls.add(Demo3Contact("", "", R.drawable.hp))
        ls.add(Demo3Contact("", "", R.drawable.chrome))
        adapter = T32Adapter(this, ls)
        gridView!!.adapter=adapter
    }
}