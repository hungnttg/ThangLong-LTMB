package com.hnq40.myapplication.tuan3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.hnq40.myapplication.R;

import java.util.ArrayList;

public class T31MainActivity extends AppCompatActivity {
    ListView listView;
    ArrayList<Demo3Contact> ls=new ArrayList<>();
    T31Adapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_t31_main);
        listView=findViewById(R.id.demo31Listview1);
        ls.add(new Demo3Contact("Nguyen Van A","18",R.drawable.android));
        ls.add(new Demo3Contact("Tran Van B","20",R.drawable.apple));
        ls.add(new Demo3Contact("Vu Van C","16",R.drawable.blogger));
        ls.add(new Demo3Contact("Hoang Thi D","22",R.drawable.dell));
        adapter=new T31Adapter(this,ls);
        listView.setAdapter(adapter);
    }
}