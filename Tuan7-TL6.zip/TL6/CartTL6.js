import React,{useState} from "react";
import {ScrollView,FlatList,Button,Text,View} from 'react-native';
import ProductTL6 from "./ProductTL6";
global.myCart=[];
const CartTL6 = (props) =>{
     const {navigation}=props;//props chua thong tin san pham truyen sang
     const data=navigation.getParam('data','');//lay du lieu va dua vao data
     //quan ly trang thai
     const [count, setCount]=useState(1);//quan ly trang thai so luong
     const [list, setList]=useState([]);//quan ly trang thai list
     //ham hien thi san pham
     const themDuLieuVaoList=()=>{
          setList(global.myCart);//lay du lieu tu gio hang
          const newList=[{data}, ...global.myCart];//them data vao gio hang
          setList(newList);//danh sach moi la newList
          global.myCart=newList;//cap nhat danh sach moi vao gio hang

     }
     //ham hien thi du lieu theo id
     const renderItems=({index,item})=>{
          return(
               <ProductTL6
               dataProd={global.myCart[index].data}
               />
          );
     }
     //tra ve ket qua
     return(
          <View>
               <ScrollView>
                    <ProductTL6
                         dataProd={data}
                    />
                    <Button
                         title="+"
                         onPress={()=>setCount(count+1)}
                    />
                    <Button
                         title="-"
                         onPress={()=>setCount(count-1)}
                    />
                    <Text>Ban da mua {count} san pham</Text>
                    <Button
                         title="Add to cart"
                         onPress={themDuLieuVaoList}
                    />
                    <Text>Gio hang</Text>
               </ScrollView>
               <View>
                    <FlatList
                         data={global.myCart}
                         renderItem={renderItems}
                         numColumns={2}
                         removeClippedSubviews
                    />
               </View>
          </View>
     );

}
export default CartTL6;