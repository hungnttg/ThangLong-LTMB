package com.hnq40.myapplication.tuan3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.GridView;

import com.hnq40.myapplication.R;

import java.util.ArrayList;

public class Demo32MainActivity extends AppCompatActivity {
    GridView gridView;
    ArrayList<Demo32Model> ls=new ArrayList<>();
    Demo32Adapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo32_main);
        gridView=findViewById(R.id.demo32Gridview);
        ls.add(new Demo32Model(R.drawable.blogger));
        ls.add(new Demo32Model(R.drawable.dell));
        ls.add(new Demo32Model(R.drawable.hp));
        ls.add(new Demo32Model(R.drawable.android));
        ls.add(new Demo32Model(R.drawable.microsoft));
        ls.add(new Demo32Model(R.drawable.apple));
        ls.add(new Demo32Model(R.drawable.firefox));
        ls.add(new Demo32Model(R.drawable.chrome));
        adapter= new Demo32Adapter(ls,this);
        gridView.setAdapter(adapter);
    }
}