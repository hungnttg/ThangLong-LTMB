package com.hnq40.myapplication.tuan3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.hnq40.myapplication.R;

import java.util.ArrayList;

public class Demo31Adapter extends BaseAdapter {
    private ArrayList<Demo31Contact> ls;
    private Context context;
    //khoi tao
    public Demo31Adapter(ArrayList<Demo31Contact> ls, Context context) {
        this.ls = ls;
        this.context = context;
    }

    //dem so luong item
    @Override
    public int getCount() {
        return ls.size();
    }
    //lay ve 1 item
    @Override
    public Object getItem(int position) {
        return ls.get(position);
    }
    //lay ve id cua item
    @Override
    public long getItemId(int position) {
        return position;
    }
    //tao view + gan du lieu
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //b1- tao view -> sinh ra lop viewHolder de anh xa voi itemView
        ViewAX vax;
        //neu chua ton tai view -> tao view moi
        if(convertView==null)
        {
            vax=new ViewAX();//tao view moi
            //anh xa layout
            convertView=LayoutInflater.from(context).inflate(R.layout.demo31_itemview,null);
            //anh xa tung thanh phan
            vax.img_hinh=convertView.findViewById(R.id.demo31_item_hinh);
            vax.tv_ten=convertView.findViewById(R.id.demo31_item_ten);
            vax.tv_tuoi=convertView.findViewById(R.id.demo31_item_tuoi);
            //tao template de lan sau su dung
            convertView.setTag(vax);
        }
        else //neu da ton tai view -> lay view da ton tai ra dung
        {
            vax=(ViewAX) convertView.getTag();
        }
        //b2- gan du lieu
        vax.img_hinh.setImageResource(ls.get(position).getHinh());
        vax.tv_ten.setText(ls.get(position).getTen());
        vax.tv_tuoi.setText(ls.get(position).getTuoi());
        return convertView;
    }
    //dinh nghia class viewHolder
    class ViewAX{
        ImageView img_hinh;
        TextView tv_ten,tv_tuoi;
    }
}
