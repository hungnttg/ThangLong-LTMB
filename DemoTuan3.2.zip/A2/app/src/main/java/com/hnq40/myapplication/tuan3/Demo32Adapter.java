package com.hnq40.myapplication.tuan3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;

import com.hnq40.myapplication.R;

import java.util.ArrayList;

public class Demo32Adapter extends BaseAdapter {
    private ArrayList<Demo32Model> ls;
    private Context context;

    public Demo32Adapter(ArrayList<Demo32Model> ls, Context context) {
        this.ls = ls;
        this.context = context;
    }

    @Override
    public int getCount() {
        return ls.size();
    }

    @Override
    public Object getItem(int position) {
        return ls.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //1.tao view
        ViewAX1 vax;
        if(convertView==null)
        {
            vax=new ViewAX1();
            convertView= LayoutInflater.from(context).inflate(R.layout.demo32_itemview,null);
            vax.img_hinh=convertView.findViewById(R.id.demo32_item_hinh);
            convertView.setTag(vax);
        }
        else
        {
            vax=(ViewAX1) convertView.getTag();
        }
        //2.gan du lieu
        vax.img_hinh.setImageResource(ls.get(position).getHinh());
        return convertView;
    }
    class ViewAX1 {
        ImageView img_hinh;
    }
}
