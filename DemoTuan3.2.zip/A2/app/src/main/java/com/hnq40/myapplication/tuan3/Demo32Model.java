package com.hnq40.myapplication.tuan3;

public class Demo32Model {
    private int hinh;

    public Demo32Model(int hinh) {
        this.hinh = hinh;
    }

    public Demo32Model() {
    }

    public int getHinh() {
        return hinh;
    }

    public void setHinh(int hinh) {
        this.hinh = hinh;
    }
}
