package com.hnq40.myapplication.tuan2

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import com.hnq40.myapplication.R

class Ac1MainActivity : AppCompatActivity() {
    //khai bao bien
    var txt1 : EditText? = null
    var btn1 : Button? = null
    var context : Context? = this
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ac1_main)
        //anh xa
        txt1=findViewById(R.id.demo2Ac1Txt1)
        var txt2=findViewById<EditText>(R.id.demo2Ac1Txt2)
        btn1=findViewById(R.id.demo2Ac1Btn1)
        //xu ly su kien button
        btn1?.setOnClickListener {
            //dinh huong chuyen du lieu
            var intent = Intent(context,Ac3MainActivity::class.java)
            //dua du lieu o thu nhat vao intent
            intent.putExtra("so1",txt1?.text.toString())
            intent.putExtra("so2",txt2.text.toString())
            //bat dau van chuyen du lieu
            startActivity(intent)
        }

    }
}