package com.hnq40.myapplication.tuan3

class ThongTin {
    var ten: String? = null
    var tuoi: String?= null
    var hinh: Int? = null

    constructor()
    constructor(ten: String?, tuoi: String?, hinh: Int?) {
        this.ten = ten
        this.tuoi = tuoi
        this.hinh = hinh
    }

}