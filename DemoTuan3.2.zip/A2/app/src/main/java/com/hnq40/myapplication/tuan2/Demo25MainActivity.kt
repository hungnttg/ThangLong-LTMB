package com.hnq40.myapplication.tuan2

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import com.hnq40.myapplication.R


class Demo25MainActivity : AppCompatActivity() {
    var listview: ListView? = null;
    var context: Context = this
    var txt2: EditText? = null
    var btn1: Button? = null
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_demo21_main)
        //anh xa
        var txt1 = findViewById<EditText>(R.id.demo21Txt1)
        txt2 = findViewById(R.id.demo21Txt2)
        btn1 = findViewById<Button>(R.id.demo21Btn1)
        btn1?.setOnClickListener {
            //Dinh huong di chuyen
            val intent = Intent(context, Demo22MainActivity::class.java)
            //boc hang len
            intent.putExtra("so1", txt1.text.toString())
            intent.putExtra("so2", txt2?.text.toString())
            //no may
            startActivity(intent)
        }
        listview=findViewById(R.id.demo21Listview)
        //var arr = arrayOf<String>("1","2","3")
        //arr.set(3,"4")
        var arr = ArrayList<String>()
        arr.add("1")
        arr.add("22")
        arr.add("33")
        var adap: ArrayAdapter<*>
        = ArrayAdapter(this,
                android.R.layout.simple_list_item_1,arr)
       listview?.adapter = adap
        

    }
}