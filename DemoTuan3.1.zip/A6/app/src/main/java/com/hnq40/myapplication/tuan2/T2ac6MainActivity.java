package com.hnq40.myapplication.tuan2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.hnq40.myapplication.R;

import java.util.ArrayList;

public class T2ac6MainActivity extends AppCompatActivity {
    ListView listView;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_t2ac6_main);
        listView=findViewById(R.id.demo2Lv1);
        ArrayList ls=new ArrayList<String>();
        ls.add("1");
        ls.add("2");
        ls.add("3");
        ls.add("4");
        ArrayAdapter a=new ArrayAdapter(this, android.R.layout.simple_list_item_1,ls);
        listView.setAdapter(a);
    }
}