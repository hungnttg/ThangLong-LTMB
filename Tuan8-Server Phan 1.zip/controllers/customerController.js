//ket noi voi csdl mysql
let controller ={};//mang chua controller
//list: liet ke khach hang
controller.list = (req,res)=>{
    req.getConnection((err,conn)=>{
        if (err) throw err;
        conn.query('select * from customer',(err,customers)=>{
            if (err) throw err;
            res.render('customers',{data: customers});//tra ve cho view
        });
    });
}
//save: luu khach hang
controller.save=(req,res)=>{
    const data=req.body;//lay du lieu tu form
    req.getConnection((err,conn)=>{
        conn.query('insert into customer set ?',data,(err,customer)=>{
            console.log(customer);
            res.redirect('/');//goi view goc
        });
    });
}
//edit: get: truyen du lieu len form can sua
controller.edit=(req,res)=>{
    const {id}=req.params;//lay ve tham so truyen
    req.getConnection((err,conn)=>{
        conn.query('select * from customer where id = ?',[id],(err,rows)=>{
            res.render('customers_edit',{data: rows[0]});//ket xuat du lieu
        });
    });
}
//update: post: update du lieu vao db
controller.update=(req,res)=>{
    const {id}=req.params;//lay ve tham so truyen
    const newCustomer=req.body;//du lieu nguoi dung sau khi nhap update
    req.getConnection((err,conn)=>{
        conn.query('update customer set ? where id = ?',[newCustomer,id],(err,rows)=>{
            res.redirect('/');
        });
    });
}
//delete: get: delete du lieu tu db
controller.delete=(req,res)=>{
    const {id}=req.params;
    req.getConnection((err,conn)=>{
        conn.query('delete from customer where id = ?',[id],(err,rows)=>{
            res.redirect('/');//tra ve thu muc goc
        });
    });
}
module.exports= controller;