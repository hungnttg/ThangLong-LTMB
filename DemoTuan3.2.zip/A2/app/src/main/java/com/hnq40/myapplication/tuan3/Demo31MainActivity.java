package com.hnq40.myapplication.tuan3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

import com.hnq40.myapplication.R;

import java.util.ArrayList;

public class Demo31MainActivity extends AppCompatActivity {
    ListView listView;
    Demo31Adapter adapter;
    ArrayList<Demo31Contact> ls=new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo31_main);
        listView=findViewById(R.id.demo31Listview);
        ls.add(new Demo31Contact("Nguyen Van A","18",R.drawable.apple));
        ls.add(new Demo31Contact("Tran Van B","20",R.drawable.hp));
        ls.add(new Demo31Contact("Vu Van C","15",R.drawable.dell));
        ls.add(new Demo31Contact("Nguyen Thi D","17",R.drawable.microsoft));
        ls.add(new Demo31Contact("Nguyen Van E","22",R.drawable.android));
        ls.add(new Demo31Contact("Nguyen Van F","23",R.drawable.blogger));
        adapter=new Demo31Adapter(ls,this);
        listView.setAdapter(adapter);

    }
}