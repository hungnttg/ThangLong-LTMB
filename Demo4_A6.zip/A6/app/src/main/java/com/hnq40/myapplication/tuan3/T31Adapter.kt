package com.hnq40.myapplication.tuan3

import android.content.Context
import com.hnq40.myapplication.tuan3.Demo3Contact
import android.widget.BaseAdapter
import android.view.ViewGroup
import com.hnq40.myapplication.tuan3.T31Adapter.ViewAnhXa
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import com.hnq40.myapplication.R
import android.widget.TextView
import java.util.ArrayList

class T31Adapter     //khoi tao
(private val context: Context, var ls: ArrayList<Demo3Contact>) : BaseAdapter() {
    //tong cac item
    override fun getCount(): Int {
        return ls.size
    }

    //tra ve 1 item theo vi tri
    override fun getItem(position: Int): Any {
        return ls[position]
    }

    //lay ve id cua item
    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    //tao view= tao layout+ gan du lieu
    override fun getView(position: Int, convertView: View, parent: ViewGroup): View {
        //1- Tao layout
        var convertView = convertView
        val vax: ViewAnhXa
        if (convertView == null) //neu chua co view thi tao view moi
        {
            vax = ViewAnhXa()
            //anh xa layout vao code java
            convertView = LayoutInflater.from(context).inflate(R.layout.demo31_item_view, null)
            //anh xa tung thanh phan cua layout
            vax.img_hinh = convertView.findViewById(R.id.demo31_item_hinh)
            vax.tv_ten = convertView.findViewById(R.id.demo31_item_ten)
            vax.tv_tuoi = convertView.findViewById(R.id.demo31_item_tuoi)
            //tao template de lan sau su dung
            convertView.tag = vax
        } else  //neu da ton tai view tu truoc thi lay ra su dung
        {
            vax = convertView.tag as ViewAnhXa
        }
        //2. gan du lieu
        vax.img_hinh!!.setImageResource(ls[position].hinh)
        vax.tv_ten!!.text = ls[position].ten
        vax.tv_tuoi!!.text = ls[position].tuoi
        return convertView
    }

    inner class ViewAnhXa {
        var img_hinh: ImageView? = null
        var tv_ten: TextView? = null
        var tv_tuoi: TextView? = null
    }
}