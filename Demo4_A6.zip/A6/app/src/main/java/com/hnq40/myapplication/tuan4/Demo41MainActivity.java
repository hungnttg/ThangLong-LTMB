package com.hnq40.myapplication.tuan4;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.hnq40.myapplication.R;
public class Demo41MainActivity extends AppCompatActivity {
    Button btnGet;
    TextView tvKQ;
    Context context=this;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_demo41_main);
        btnGet=findViewById(R.id.demo41BtnGetData);
        tvKQ=findViewById(R.id.demo41TvKQ);
        VolleyFn fn=new VolleyFn();
        btnGet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fn.getJSON_Array_Of_Objects(context,tvKQ);
            }
        });
    }
}