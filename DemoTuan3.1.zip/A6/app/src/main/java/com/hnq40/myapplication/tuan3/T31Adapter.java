package com.hnq40.myapplication.tuan3;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.hnq40.myapplication.R;

import java.util.ArrayList;
import java.util.List;

public class T31Adapter extends BaseAdapter {
    private Context context;
    ArrayList<Demo3Contact> ls;
    //khoi tao
    public T31Adapter(Context context, ArrayList<Demo3Contact> ls) {
        this.context = context;
        this.ls = ls;
    }

    //tong cac item
    @Override
    public int getCount() {
        return ls.size();
    }
    //tra ve 1 item theo vi tri
    @Override
    public Object getItem(int position) {
        return ls.get(position);
    }
    //lay ve id cua item
    @Override
    public long getItemId(int position) {
        return position;
    }
    //tao view= tao layout+ gan du lieu
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        //1- Tao layout
        ViewAnhXa vax;
        if(convertView==null)//neu chua co view thi tao view moi
        {
            vax=new ViewAnhXa();
            //anh xa layout vao code java
            convertView=LayoutInflater.from(context).inflate(R.layout.demo31_item_view,null);
            //anh xa tung thanh phan cua layout
            vax.img_hinh=convertView.findViewById(R.id.demo31_item_hinh);
            vax.tv_ten=convertView.findViewById(R.id.demo31_item_ten);
            vax.tv_tuoi=convertView.findViewById(R.id.demo31_item_tuoi);
            //tao template de lan sau su dung
            convertView.setTag(vax);
        }
        else//neu da ton tai view tu truoc thi lay ra su dung
        {
            vax=(ViewAnhXa) convertView.getTag();
        }
        //2. gan du lieu
        vax.img_hinh.setImageResource(ls.get(position).getHinh());
        vax.tv_ten.setText(ls.get(position).getTen());
        vax.tv_tuoi.setText(ls.get(position).getTuoi());
        return convertView;
    }
    public class ViewAnhXa{
        public ImageView img_hinh;
        public TextView tv_ten;
        public TextView tv_tuoi;
    }
}
