package com.hnq40.myapplication.tuan2

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.hnq40.myapplication.R

class Ac3MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ac3_main)
        var tv1 = findViewById<TextView>(R.id.demo2Ac3Tv1)
        var intent: Intent = getIntent()
        var chuoi1 : String? = intent.getStringExtra("so1")
        var chuoi2 : String? = intent.getStringExtra("so2")
        var so1 : Float = chuoi1!!.toFloat()
        var so2 : Float = chuoi2!!.toFloat()
        var tong : Float = so1+so2
        tv1.setText(tong.toString())
    }
}