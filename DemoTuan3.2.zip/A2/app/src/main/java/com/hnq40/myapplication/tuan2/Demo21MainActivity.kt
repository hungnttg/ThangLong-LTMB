package com.hnq40.myapplication.tuan2

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.widget.EditText
import android.os.Bundle
import com.hnq40.myapplication.R
import android.content.Intent
import android.view.View
import android.widget.Button
import com.hnq40.myapplication.tuan2.Demo22MainActivity

class Demo21MainActivity : AppCompatActivity() {
    var context: Context = this
    var txt2: EditText? = null
    var btn1: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_demo21_main)
        //anh xa
       var txt1 = findViewById<EditText>(R.id.demo21Txt1)
        txt2 = findViewById(R.id.demo21Txt2)
        btn1 = findViewById<Button>(R.id.demo21Btn1)
        btn1?.setOnClickListener {
            //Dinh huong di chuyen
            val intent = Intent(context, Demo22MainActivity::class.java)
            //boc hang len
            intent.putExtra("so1", txt1.text.toString())
            intent.putExtra("so2", txt2?.text.toString())
            //no may
            startActivity(intent)
        }
    }
}