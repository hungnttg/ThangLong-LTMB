package com.hnq40.myapplication.tuan3

import android.content.Context
import com.hnq40.myapplication.tuan3.Demo3Contact
import android.widget.BaseAdapter
import android.view.ViewGroup
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import com.hnq40.myapplication.R
import java.util.ArrayList

class T32Adapter(private val context: Context,
                 private val ls: ArrayList<Demo3Contact>)
    : BaseAdapter() {
    override fun getCount(): Int {
        return ls.size
    }
    override fun getItem(position: Int): Any {
        return ls[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View, parent: ViewGroup): View {
        //1.anh xa layout
        var convertView = convertView
        convertView = LayoutInflater.from(context)
                .inflate(R.layout.demo32_item_view, null)
        //2.anh xa thanh phan
        val imageView = convertView.findViewById<ImageView>(R.id.demo32_item_hinh)
        //3. Gan du lieu
        imageView.setImageResource(ls[position].hinh)
        return convertView
    }
}